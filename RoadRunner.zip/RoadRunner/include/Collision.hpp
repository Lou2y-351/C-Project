#pragma once

#include "Types.hpp"

// ──────────────────────────────────────────────────────────
//  AABB overlap test
// ──────────────────────────────────────────────────────────
[[nodiscard]] bool overlaps(const Rect& a, const Rect& b) noexcept;
