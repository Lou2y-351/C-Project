#pragma once

#include <cstdint>

// ──────────────────────────────────────────────────────────
//  Window / world constants
// ──────────────────────────────────────────────────────────
constexpr int32_t  ScreenW      = 960;
constexpr int32_t  ScreenH      = 540;
constexpr int32_t  TargetFps    = 60;

constexpr float    Gravity      = 0.45f;
constexpr float    JumpVelocity = -9.0f;
constexpr float    CarSpeed     = 5.5f;

constexpr float    GroundY      = 390.f;
constexpr float    HillBaseY    = 250.f;

constexpr int32_t  MaxLives     = 3;
constexpr int32_t  InvFrames    = 90;

static_assert(ScreenW   > 0, "ScreenW must be positive");
static_assert(ScreenH   > 0, "ScreenH must be positive");
static_assert(TargetFps > 0, "TargetFps must be positive");
static_assert(MaxLives  > 0, "MaxLives must be positive");
