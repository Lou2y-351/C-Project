#pragma once

#include <SDL2/SDL.h>

// ──────────────────────────────────────────────────────────
//  Road centre-line stripe
// ──────────────────────────────────────────────────────────
struct Stripe {
    static constexpr float StripeW   = 55.f;
    static constexpr float StripeH   =  7.f;
    static constexpr float StripeGap = 40.f;

    float x;

    void update(float spd) noexcept;
    void draw(SDL_Renderer* ren) const noexcept;
};
