#pragma once

#include "Types.hpp"
#include <SDL2/SDL.h>

// ──────────────────────────────────────────────────────────
//  Obstacle (tree or rock)
// ──────────────────────────────────────────────────────────
struct Obstacle {
    float        x;
    ObstacleType type;
    bool         active = true;
    float        speed;

    [[nodiscard]] float width()  const noexcept;
    [[nodiscard]] float height() const noexcept;
    [[nodiscard]] float top()    const noexcept;
    [[nodiscard]] Rect  hitbox() const noexcept;

    void update() noexcept;
    void draw(SDL_Renderer* ren) const noexcept;

private:
    void drawTree(SDL_Renderer* ren) const noexcept;
    void drawRock(SDL_Renderer* ren) const noexcept;
};
