#pragma once

#include "Types.hpp"
#include <SDL2/SDL.h>
#include <cstdint>

// ──────────────────────────────────────────────────────────
//  Low-level SDL draw helpers
// ──────────────────────────────────────────────────────────
void setColor   (SDL_Renderer* ren, Col c) noexcept;

void fillRect   (SDL_Renderer* ren, float x, float y,
                 float w, float h, Col c) noexcept;

void drawRect   (SDL_Renderer* ren, float x, float y,
                 float w, float h, Col c) noexcept;

void fillCircle (SDL_Renderer* ren, int32_t cx, int32_t cy,
                 int32_t r, Col c) noexcept;
