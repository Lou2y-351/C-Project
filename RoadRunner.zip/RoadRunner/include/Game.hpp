#pragma once

#include "Car.hpp"
#include "Cloud.hpp"
#include "Hill.hpp"
#include "Obstacle.hpp"
#include "Particle.hpp"
#include "Stripe.hpp"
#include "Text.hpp"
#include "Types.hpp"

#include <SDL2/SDL.h>
#include <cstdint>
#include <memory>
#include <random>
#include <vector>

// ──────────────────────────────────────────────────────────
//  Game  (owns SDL window + renderer — Rule of 5)
// ──────────────────────────────────────────────────────────
class Game {
public:
    Game();
    ~Game();

    Game(const Game&)            = delete;
    Game& operator=(const Game&) = delete;
    Game(Game&&)                 = delete;
    Game& operator=(Game&&)      = delete;

    void run();

private:
    // Init
    void initClouds();
    void initHills();
    void initStripes();
    void resetGame();

    // Update
    void update();
    void spawnCrash(float cx, float cy);

    // Draw
    void draw();
    void drawHUD();
    void drawMenu();
    void drawGameOver();

    // SDL resources
    SDL_Window*           _win = nullptr;
    SDL_Renderer*         _ren = nullptr;
    std::unique_ptr<Text> _txt;

    // Game objects
    std::unique_ptr<Car>  _car;
    std::vector<Obstacle> _obs;
    std::vector<Particle> _parts;
    std::vector<Cloud>    _clouds;
    std::vector<Hill>     _hills;
    std::vector<Stripe>   _stripes;

    // State
    GameState   _state   = GameState::Menu;
    int32_t     _lives   = MaxLives;
    int64_t     _score   = 0;
    int64_t     _hiScore = 0;
    float       _gameSpd = 2.8f;
    int32_t     _frame   = 0;
    int32_t     _nextObs = 90;

    std::mt19937 _rng{std::random_device{}()};
};
