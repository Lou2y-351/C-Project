#pragma once

#include "Types.hpp"

// ──────────────────────────────────────────────────────────
//  Particle  (POD)
// ──────────────────────────────────────────────────────────
struct Particle {
    float x, y, vx, vy, life, maxLife;
    Col   color;

    [[nodiscard]] bool alive() const noexcept { return life > 0.f; }
};
