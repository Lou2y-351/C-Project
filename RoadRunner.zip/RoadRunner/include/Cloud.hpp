#pragma once

#include "Types.hpp"
#include <SDL2/SDL.h>

// ──────────────────────────────────────────────────────────
//  Scrolling cloud
// ──────────────────────────────────────────────────────────
struct Cloud {
    float x, y, w, h, speed;

    void update() noexcept;
    void draw(SDL_Renderer* ren) const noexcept;
};
