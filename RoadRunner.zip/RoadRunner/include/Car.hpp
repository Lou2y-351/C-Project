#pragma once

#include "Types.hpp"
#include <SDL2/SDL.h>
#include <cstdint>

// ──────────────────────────────────────────────────────────
//  Player kart
// ──────────────────────────────────────────────────────────
class Car {
public:
    float x, y;
    float cw = 55.f, ch = 26.f;

    explicit Car(float startX) noexcept;

    Car(const Car&)            = default;
    Car& operator=(const Car&) = default;
    Car(Car&&)                 = default;
    Car& operator=(Car&&)      = default;
    ~Car()                     = default;

    void handleInput(const uint8_t* keys) noexcept;
    void tryJump()       noexcept;
    void update()        noexcept;
    void makeInvincible() noexcept;

    [[nodiscard]] Rect hitbox()      const noexcept;
    [[nodiscard]] bool isInvincible() const noexcept;

    void draw(SDL_Renderer* ren) const noexcept;

private:
    float   _vy         = 0.f;
    bool    _onGround   = true;
    bool    _invincible = false;
    int32_t _invFrames  = 0;
};
