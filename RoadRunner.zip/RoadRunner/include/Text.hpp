#pragma once

#include "Constants.hpp"
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <cstdint>
#include <string>

// ──────────────────────────────────────────────────────────
//  Text renderer  (owns TTF resources — Rule of 5)
// ──────────────────────────────────────────────────────────
class Text {
public:
    enum class Size : uint8_t { Big, Med, Small };

    Text();
    ~Text();

    Text(const Text&)            = delete;
    Text& operator=(const Text&) = delete;
    Text(Text&&)                 = delete;
    Text& operator=(Text&&)      = delete;

    void draw(SDL_Renderer* ren, const std::string& text,
              int32_t x, int32_t y,
              SDL_Color col = {255, 255, 255, 255},
              Size sz = Size::Med) const noexcept;

    void drawCentered(SDL_Renderer* ren, const std::string& text,
                      int32_t y,
                      SDL_Color col = {255, 255, 255, 255},
                      Size sz = Size::Med) const noexcept;

private:
    TTF_Font* _big = nullptr;
    TTF_Font* _med = nullptr;
    TTF_Font* _sml = nullptr;

    [[nodiscard]] TTF_Font* fontFor(Size sz) const noexcept;
};
