#pragma once

#include "Types.hpp"
#include <SDL2/SDL.h>

// ──────────────────────────────────────────────────────────
//  Scrolling background hill silhouette
// ──────────────────────────────────────────────────────────
struct Hill {
    float x, w, h, speed;
    Col   color;

    void update() noexcept;
    void draw(SDL_Renderer* ren) const noexcept;
};
