#include "Game.hpp"
#include "Collision.hpp"
#include "Constants.hpp"
#include "DrawUtils.hpp"

#include <algorithm>
#include <cassert>
#include <cmath>
#include <iostream>
#include <random>
#include <sstream>
#include <stdexcept>

// ── Constructor / Destructor ──────────────────────────────

Game::Game()
{
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_EVENTS) < 0)
        throw std::runtime_error(SDL_GetError());

    _win = SDL_CreateWindow("RoadRunner",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        ScreenW, ScreenH, SDL_WINDOW_SHOWN);
    if (!_win) throw std::runtime_error(SDL_GetError());

    _ren = SDL_CreateRenderer(_win, -1,
        SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (!_ren) throw std::runtime_error(SDL_GetError());

    SDL_RenderSetLogicalSize(_ren, ScreenW, ScreenH);
    SDL_SetRenderDrawBlendMode(_ren, SDL_BLENDMODE_BLEND);

    _txt = std::make_unique<Text>();
    initClouds();
    initHills();
    initStripes();
    resetGame();
}

Game::~Game()
{
    _txt.reset();
    if (_ren) SDL_DestroyRenderer(_ren);
    if (_win) SDL_DestroyWindow(_win);
    SDL_Quit();
}

// ── Public ────────────────────────────────────────────────

void Game::run()
{
    bool quit = false;
    while (!quit) {
        const uint32_t t0 = SDL_GetTicks();

        SDL_Event ev;
        while (SDL_PollEvent(&ev)) {
            if (ev.type == SDL_QUIT) { quit = true; break; }
            if (ev.type == SDL_KEYDOWN) {
                const SDL_Scancode k = ev.key.keysym.scancode;
                if (k == SDL_SCANCODE_ESCAPE) { quit = true; break; }
                if (_state == GameState::Menu && k == SDL_SCANCODE_RETURN)
                    _state = GameState::Playing;
                if (_state == GameState::Playing &&
                    (k == SDL_SCANCODE_SPACE || k == SDL_SCANCODE_UP || k == SDL_SCANCODE_W))
                    _car->tryJump();
                if (_state == GameState::GameOver && k == SDL_SCANCODE_R)
                    resetGame();
            }
        }

        if (_state == GameState::Playing) update();
        draw();

        const int32_t elapsed = static_cast<int32_t>(SDL_GetTicks() - t0);
        const int32_t delay   = 1000 / TargetFps - elapsed;
        if (delay > 0) SDL_Delay(static_cast<uint32_t>(delay));
    }
}

// ── Init ─────────────────────────────────────────────────

void Game::initClouds()
{
    std::uniform_real_distribution<float> xDist(0.f, static_cast<float>(ScreenW));
    std::uniform_real_distribution<float> yDist(30.f, 160.f);
    std::uniform_real_distribution<float> sDist(0.3f, 0.7f);
    std::uniform_real_distribution<float> wDist(80.f, 160.f);
    _clouds.clear();
    for (int32_t i = 0; i < 5; ++i) {
        const float w = wDist(_rng);
        _clouds.push_back({xDist(_rng), yDist(_rng), w, w * 0.45f, sDist(_rng)});
    }
}

void Game::initHills()
{
    _hills.clear();
    _hills.push_back({  0.f, 280.f, 120.f, 0.06f, {50,  160, 60}});
    _hills.push_back({200.f, 200.f, 100.f, 0.04f, {60,  170, 65}});
    _hills.push_back({420.f, 320.f, 140.f, 0.05f, {45,  155, 55}});
    _hills.push_back({680.f, 240.f, 110.f, 0.04f, {55,  165, 60}});
}

void Game::initStripes()
{
    _stripes.clear();
    for (int32_t i = 0; i < 5; ++i)
        _stripes.push_back({static_cast<float>(i) * (Stripe::StripeW + Stripe::StripeGap)});
}

void Game::resetGame()
{
    _car     = std::make_unique<Car>(100.f);
    _obs.clear();
    _parts.clear();
    _lives   = MaxLives;
    _score   = 0;
    _frame   = 0;
    _gameSpd = 2.8f;
    _nextObs = 90;
    _state   = GameState::Playing;
}

// ── Update ───────────────────────────────────────────────

void Game::update()
{
    assert(_car != nullptr);
    ++_frame;
    ++_score;
    _gameSpd += 0.0015f;

    const uint8_t* keys = SDL_GetKeyboardState(nullptr);
    _car->handleInput(keys);
    _car->update();

    for (auto& cl : _clouds)  cl.update();
    for (auto& hl : _hills)   hl.update();
    for (auto& st : _stripes) st.update(_gameSpd);

    if (--_nextObs <= 0) {
        std::uniform_int_distribution<int32_t> typeDist(0, 1);
        std::uniform_int_distribution<int32_t> gapDist(120, 260);
        _obs.push_back({static_cast<float>(ScreenW),
                        static_cast<ObstacleType>(typeDist(_rng)),
                        true, _gameSpd});
        _nextObs = gapDist(_rng);
    }
    for (auto& o : _obs) o.update();

    if (!_car->isInvincible()) {
        for (auto& o : _obs) {
            if (!o.active) continue;
            if (overlaps(_car->hitbox(), o.hitbox())) {
                o.active = false;
                spawnCrash(_car->x + _car->cw / 2.f,
                           _car->y + _car->ch / 2.f);
                --_lives;
                if (_lives <= 0) {
                    _hiScore = std::max(_hiScore, _score);
                    _state   = GameState::GameOver;
                } else {
                    _car->makeInvincible();
                }
                break;
            }
        }
    }

    for (auto& p : _parts) {
        p.x   += p.vx;
        p.y   += p.vy;
        p.vy  += 0.3f;
        p.life -= 1.f;
    }

    _obs.erase(std::remove_if(_obs.begin(), _obs.end(),
        [](const Obstacle& o) { return !o.active; }), _obs.end());
    _parts.erase(std::remove_if(_parts.begin(), _parts.end(),
        [](const Particle& p) { return !p.alive(); }), _parts.end());
}

void Game::spawnCrash(float cx, float cy)
{
    assert(std::isfinite(cx) && std::isfinite(cy));
    std::uniform_real_distribution<float> angleDist(0.f, 6.28f);
    std::uniform_real_distribution<float> speedDist(2.f, 9.f);
    std::uniform_real_distribution<float> lifeDist(15.f, 40.f);
    for (int32_t i = 0; i < 28; ++i) {
        const float a = angleDist(_rng);
        const float s = speedDist(_rng);
        const Col   c = (i % 2 == 0) ? Col{255, 200, 0} : Col{255, 60, 0};
        _parts.push_back({cx, cy, std::cos(a) * s, std::sin(a) * s,
                          lifeDist(_rng), 40.f, c});
    }
}

// ── Draw ─────────────────────────────────────────────────

void Game::draw()
{
    assert(_ren != nullptr);

    // Sky + ground background
    fillRect(_ren, 0.f, 0.f,
             static_cast<float>(ScreenW), static_cast<float>(ScreenH / 2),
             {135, 206, 235});
    fillRect(_ren, 0.f, static_cast<float>(ScreenH / 2),
             static_cast<float>(ScreenW), static_cast<float>(ScreenH / 2),
             {160, 220, 160});

    for (const auto& cl : _clouds) cl.draw(_ren);
    for (const auto& hl : _hills)  hl.draw(_ren);

    // Ground / road
    fillRect(_ren, 0.f, GroundY,
             static_cast<float>(ScreenW), static_cast<float>(ScreenH) - GroundY,
             {80, 160, 60});
    fillRect(_ren, 0.f, GroundY,
             static_cast<float>(ScreenW), 8.f, {50, 130, 40});
    fillRect(_ren, 0.f, GroundY + 8.f,
             static_cast<float>(ScreenW), 60.f, {80, 160, 60});

    for (const auto& st : _stripes) st.draw(_ren);
    for (const auto& o  : _obs)     o.draw(_ren);
    _car->draw(_ren);

    // Particles
    for (const auto& p : _parts) {
        const float alpha = p.life / p.maxLife;
        Col c = p.color;
        c.a   = static_cast<uint8_t>(alpha * 255.f);
        fillRect(_ren, p.x, p.y, 5.f, 5.f, c);
    }

    drawHUD();
    if (_state == GameState::Menu)     drawMenu();
    if (_state == GameState::GameOver) drawGameOver();

    SDL_RenderPresent(_ren);
}

void Game::drawHUD()
{
    assert(_txt != nullptr);
    std::ostringstream ss;
    ss << "Score: " << _score;
    _txt->draw(_ren, ss.str(), 10, 8, {255, 255, 255, 255}, Text::Size::Med);

    std::ostringstream hs;
    hs << "Best: " << _hiScore;
    _txt->draw(_ren, hs.str(), 10, 36, {255, 230, 60, 255}, Text::Size::Small);

    std::ostringstream sp;
    sp << "Speed: " << static_cast<int32_t>(_gameSpd);
    _txt->draw(_ren, sp.str(), ScreenW - 150, 8, {200, 255, 200, 255}, Text::Size::Small);

    for (int32_t i = 0; i < MaxLives; ++i) {
        const Col   c  = (i < _lives) ? Col{220, 30, 30} : Col{80, 80, 80};
        const float hx = static_cast<float>(ScreenW) - 40.f - static_cast<float>(i) * 34.f;
        constexpr float hy = 38.f;
        fillRect(_ren, hx,        hy + 3.f,   9.f, 11.f, c);
        fillRect(_ren, hx + 9.f,  hy + 3.f,   9.f, 11.f, c);
        fillRect(_ren, hx - 2.f,  hy + 7.f,  23.f,  9.f, c);
        fillRect(_ren, hx + 2.f,  hy + 15.f, 15.f,  5.f, c);
        fillRect(_ren, hx + 5.f,  hy + 19.f,  9.f,  3.f, c);
    }
}

void Game::drawMenu()
{
    assert(_ren != nullptr && _txt != nullptr);
    setColor(_ren, {0, 0, 0, 150});
    SDL_Rect ovl{0, 0, ScreenW, ScreenH};
    SDL_RenderFillRect(_ren, &ovl);

    _txt->drawCentered(_ren, "ROADRUNNER",            130, {255, 220,  40, 255}, Text::Size::Big);
    _txt->drawCentered(_ren, "Press ENTER to start",  210, {255, 255, 255, 255}, Text::Size::Med);
    _txt->drawCentered(_ren, "LEFT / RIGHT  -  move", 260, {180, 230, 255, 255}, Text::Size::Small);
    _txt->drawCentered(_ren, "SPACE / UP    -  jump", 285, {180, 230, 255, 255}, Text::Size::Small);
    _txt->drawCentered(_ren, "ESC           -  quit", 310, {180, 230, 255, 255}, Text::Size::Small);
}

void Game::drawGameOver()
{
    assert(_ren != nullptr && _txt != nullptr);
    setColor(_ren, {0, 0, 0, 160});
    SDL_Rect ovl{ScreenW / 2 - 200, ScreenH / 2 - 120, 400, 220};
    SDL_RenderFillRect(_ren, &ovl);
    drawRect(_ren,
             static_cast<float>(ScreenW / 2 - 200),
             static_cast<float>(ScreenH / 2 - 120),
             400.f, 220.f, {220, 30, 30, 255});

    _txt->drawCentered(_ren, "GAME OVER",
                       ScreenH / 2 - 100, {255, 60, 60, 255}, Text::Size::Big);

    std::ostringstream s1, s2;
    s1 << "Score:  " << _score;
    s2 << "Best:   " << _hiScore;
    _txt->drawCentered(_ren, s1.str(), ScreenH / 2 - 20, {255, 255, 255, 255}, Text::Size::Med);
    _txt->drawCentered(_ren, s2.str(), ScreenH / 2 + 15, {255, 220,  60, 255}, Text::Size::Med);
    _txt->drawCentered(_ren, "R = Restart    ESC = Quit",
                       ScreenH / 2 + 70, {160, 220, 255, 255}, Text::Size::Small);
}
