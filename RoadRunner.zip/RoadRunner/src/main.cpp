#include "Game.hpp"

#include <iostream>

int main(int /*argc*/, char** /*argv*/)
{
    try {
        Game g;
        g.run();
    } catch (const std::exception& e) {
        std::cerr << "Fatal: " << e.what() << "\n";
        return 1;
    }
    return 0;
}
