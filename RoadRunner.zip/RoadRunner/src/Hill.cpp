#include "Hill.hpp"
#include "Constants.hpp"
#include "DrawUtils.hpp"

#include <cassert>
#include <cstdint>

void Hill::update() noexcept
{
    x -= speed;
    if (x + w < 0.f) x = static_cast<float>(ScreenW) + 50.f;
}

void Hill::draw(SDL_Renderer* ren) const noexcept
{
    assert(ren != nullptr);
    const float peak = x + w / 2.f;
    const float base = HillBaseY + h;
    setColor(ren, color);
    for (int32_t row = 0; row < static_cast<int32_t>(h); ++row) {
        const float t  = static_cast<float>(row) / h;
        const float hw = w * 0.5f * t;
        SDL_RenderDrawLineF(ren, peak - hw, base - h + static_cast<float>(row),
                                 peak + hw, base - h + static_cast<float>(row));
    }
}
