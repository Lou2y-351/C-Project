#include "Stripe.hpp"
#include "Constants.hpp"
#include "DrawUtils.hpp"

#include <cassert>

void Stripe::update(float spd) noexcept
{
    x -= spd;
    if (x + StripeW < 0.f) x += (StripeW + StripeGap) * 5.f;
}

void Stripe::draw(SDL_Renderer* ren) const noexcept
{
    assert(ren != nullptr);
    fillRect(ren, x, GroundY + 20.f, StripeW, StripeH, {240, 220, 100, 160});
}
