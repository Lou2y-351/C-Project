#include "Text.hpp"

#include <cassert>
#include <stdexcept>
#include <vector>

Text::Text()
{
    if (TTF_Init() < 0)
        throw std::runtime_error(TTF_GetError());

    const std::vector<std::string> fontPaths = {
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/opt/homebrew/share/fonts/dejavu-fonts/DejaVuSans-Bold.ttf",
        "/System/Library/Fonts/Helvetica.ttc",
        "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
        "C:/Windows/Fonts/arialbd.ttf"
    };

    for (const auto& path : fontPaths) {
        _big = TTF_OpenFont(path.c_str(), 42);
        _med = TTF_OpenFont(path.c_str(), 26);
        _sml = TTF_OpenFont(path.c_str(), 18);
        if (_big && _med && _sml) break;
        TTF_CloseFont(_big); _big = nullptr;
        TTF_CloseFont(_med); _med = nullptr;
        TTF_CloseFont(_sml); _sml = nullptr;
    }
}

Text::~Text()
{
    TTF_CloseFont(_big);
    TTF_CloseFont(_med);
    TTF_CloseFont(_sml);
    TTF_Quit();
}

void Text::draw(SDL_Renderer* ren, const std::string& text,
                int32_t x, int32_t y,
                SDL_Color col, Size sz) const noexcept
{
    assert(ren != nullptr);
    TTF_Font* f = fontFor(sz);
    if (!f) return;
    SDL_Surface* sur = TTF_RenderUTF8_Blended(f, text.c_str(), col);
    if (!sur) return;
    SDL_Texture* tex = SDL_CreateTextureFromSurface(ren, sur);
    SDL_FreeSurface(sur);
    if (!tex) return;
    int32_t tw = 0, th = 0;
    SDL_QueryTexture(tex, nullptr, nullptr, &tw, &th);
    SDL_Rect dst{x, y, tw, th};
    SDL_RenderCopy(ren, tex, nullptr, &dst);
    SDL_DestroyTexture(tex);
}

void Text::drawCentered(SDL_Renderer* ren, const std::string& text,
                        int32_t y, SDL_Color col, Size sz) const noexcept
{
    assert(ren != nullptr);
    TTF_Font* f = fontFor(sz);
    if (!f) return;
    int32_t tw = 0, th = 0;
    TTF_SizeUTF8(f, text.c_str(), &tw, &th);
    draw(ren, text, (ScreenW - tw) / 2, y, col, sz);
}

TTF_Font* Text::fontFor(Size sz) const noexcept
{
    switch (sz) {
        case Size::Big:   return _big;
        case Size::Small: return _sml;
        default:          return _med;
    }
}
