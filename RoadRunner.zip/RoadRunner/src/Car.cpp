#include "Car.hpp"
#include "Constants.hpp"
#include "DrawUtils.hpp"

#include <algorithm>
#include <cassert>

Car::Car(float startX) noexcept
    : x(startX), y(GroundY - 38.f)
{
    assert(startX >= 0.f);
}

void Car::handleInput(const uint8_t* keys) noexcept
{
    assert(keys != nullptr);
    if (keys[SDL_SCANCODE_LEFT] || keys[SDL_SCANCODE_A])
        x = std::max(0.f, x - CarSpeed);
    if (keys[SDL_SCANCODE_RIGHT] || keys[SDL_SCANCODE_D])
        x = std::min(static_cast<float>(ScreenW) - cw, x + CarSpeed);
}

void Car::tryJump() noexcept
{
    if (_onGround) { _vy = JumpVelocity; _onGround = false; }
}

void Car::update() noexcept
{
    _vy += Gravity;
    y   += _vy;
    if (y >= GroundY - ch) { y = GroundY - ch; _vy = 0.f; _onGround = true; }
    if (_invincible && --_invFrames <= 0) _invincible = false;
}

Rect Car::hitbox() const noexcept
{
    return {x + 8.f, y + 8.f, cw - 16.f, ch - 8.f};
}

void Car::makeInvincible() noexcept
{
    _invincible = true;
    _invFrames  = InvFrames;
}

bool Car::isInvincible() const noexcept
{
    return _invincible;
}

void Car::draw(SDL_Renderer* ren) const noexcept
{
    assert(ren != nullptr);
    if (_invincible && (_invFrames / 6) % 2 == 0) return;

    const float bx = x, by = y;

    // Kart body
    fillRect(ren, bx,          by + 8.f,   cw,       ch - 8.f,  {200,  20,  20});
    fillRect(ren, bx + cw-6.f, by + 11.f,  8.f,      ch - 14.f, {180,  15,  15});
    fillRect(ren, bx + 2.f,    by + 12.f,  cw - 8.f,  4.f,      {230, 230, 230});
    fillRect(ren, bx + 10.f,   by + 5.f,   24.f,     11.f,      { 30,  30,  30});
    fillRect(ren, bx + 11.f,   by + 7.f,   15.f,      7.f,      {120, 200, 255, 180});
    fillRect(ren, bx,          by + 4.f,    6.f,     14.f,      {170,  10,  10});
    fillRect(ren, bx + cw-2.f, by + 14.f,   5.f,      7.f,      { 80,  80,  80});
    fillRect(ren, bx + 2.f,    by + ch-3.f,  7.f,      4.f,      { 60,  60,  60});
    fillRect(ren, bx + 10.f,   by + ch-3.f,  7.f,      4.f,      { 60,  60,  60});

    // Wheels
    auto wheel = [&](float wx, float wy, float r) noexcept {
        fillCircle(ren, static_cast<int32_t>(wx), static_cast<int32_t>(wy),
                   static_cast<int32_t>(r),         { 30,  30,  30});
        fillCircle(ren, static_cast<int32_t>(wx), static_cast<int32_t>(wy),
                   static_cast<int32_t>(r * 0.55f), { 90,  90,  90});
        fillCircle(ren, static_cast<int32_t>(wx), static_cast<int32_t>(wy),
                   static_cast<int32_t>(r * 0.2f),  {200, 200, 200});
    };
    wheel(bx + 11.f,     by + ch + 2.f, 9.f);
    wheel(bx + cw - 10.f, by + ch + 2.f, 9.f);

    // Driver
    const float hx = bx + 14.f, hy = by - 12.f;
    fillRect(ren, hx - 3.f, hy + 9.f,  14.f, 7.f, { 30,  30, 200});
    fillRect(ren, hx - 1.f, hy + 1.f,  11.f, 9.f, {255, 200, 140});
    fillRect(ren, hx - 3.f, hy - 2.f,  14.f, 6.f, {200,  20,  20});
    fillRect(ren, hx - 4.f, hy + 1.f,  16.f, 3.f, {200,  20,  20});
    fillRect(ren, hx + 1.f, hy + 7.f,   5.f, 2.f, { 80,  40,  10});
    fillRect(ren, hx + 5.f, hy + 3.f,   3.f, 3.f, { 20,  20,  20});
    fillRect(ren, hx - 3.f, hy + 4.f,   2.f, 4.f, {220, 170, 110});
}
