#include "Cloud.hpp"
#include "Constants.hpp"
#include "DrawUtils.hpp"

#include <cassert>

void Cloud::update() noexcept
{
    x -= speed;
    if (x + w < 0.f) x = static_cast<float>(ScreenW) + 20.f;
}

void Cloud::draw(SDL_Renderer* ren) const noexcept
{
    assert(ren != nullptr);
    auto blob = [&](float ox, float oy, float r) noexcept {
        fillRect(ren, x + ox - r, y + oy - r * 0.6f,
                 r * 2.f, r * 1.2f, {255, 255, 255, 220});
    };
    blob(0.f,       0.f,        w * 0.25f);
    blob(w * 0.3f, -h * 0.3f,  w * 0.30f);
    blob(w * 0.6f,  0.f,        w * 0.25f);
}
