#include "DrawUtils.hpp"

#include <cassert>
#include <cmath>

void setColor(SDL_Renderer* ren, Col c) noexcept
{
    assert(ren != nullptr);
    SDL_SetRenderDrawColor(ren, c.r, c.g, c.b, c.a);
}

void fillRect(SDL_Renderer* ren, float x, float y,
              float w, float h, Col c) noexcept
{
    assert(ren != nullptr);
    setColor(ren, c);
    SDL_FRect fr{x, y, w, h};
    SDL_RenderFillRectF(ren, &fr);
}

void drawRect(SDL_Renderer* ren, float x, float y,
              float w, float h, Col c) noexcept
{
    assert(ren != nullptr);
    setColor(ren, c);
    SDL_FRect fr{x, y, w, h};
    SDL_RenderDrawRectF(ren, &fr);
}

void fillCircle(SDL_Renderer* ren, int32_t cx, int32_t cy,
                int32_t r, Col c) noexcept
{
    assert(ren != nullptr);
    assert(r >= 0);
    setColor(ren, c);
    for (int32_t dy = -r; dy <= r; ++dy) {
        const int32_t dx = static_cast<int32_t>(
            std::sqrt(static_cast<double>(r * r - dy * dy)));
        SDL_RenderDrawLine(ren, cx - dx, cy + dy, cx + dx, cy + dy);
    }
}
