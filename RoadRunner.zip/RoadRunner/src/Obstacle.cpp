#include "Obstacle.hpp"
#include "Constants.hpp"
#include "DrawUtils.hpp"

#include <cassert>
#include <cstdint>

float Obstacle::width() const noexcept
{
    return type == ObstacleType::Tree ? 30.f : 34.f;
}

float Obstacle::height() const noexcept
{
    return type == ObstacleType::Tree ? 60.f : 24.f;
}

float Obstacle::top() const noexcept
{
    return GroundY - height();
}

Rect Obstacle::hitbox() const noexcept
{
    return {x + 6.f, top() + 6.f, width() - 12.f, height() - 6.f};
}

void Obstacle::update() noexcept
{
    x -= speed;
    if (x + width() < 0.f) active = false;
}

void Obstacle::draw(SDL_Renderer* ren) const noexcept
{
    assert(ren != nullptr);
    if (type == ObstacleType::Tree) drawTree(ren);
    else                            drawRock(ren);
}

void Obstacle::drawTree(SDL_Renderer* ren) const noexcept
{
    const float cx = x + width() / 2.f;
    fillRect(ren, cx - 3.f, GroundY - 24.f, 7.f, 24.f, {101, 67, 33});
    fillRect(ren, cx - 4.f, GroundY - 2.f,  8.f,  3.f, {70, 45, 20});

    for (int32_t layer = 0; layer < 3; ++layer) {
        const float ly = GroundY - 28.f - static_cast<float>(layer) * 14.f;
        const float lw = 26.f - static_cast<float>(layer) * 6.f;
        constexpr float lh = 18.f;
        const Col gc = {
            static_cast<uint8_t>(30  + layer * 10),
            static_cast<uint8_t>(140 + layer * 15),
            30, 255
        };
        for (int32_t row = 0; row < static_cast<int32_t>(lh); ++row) {
            const float t  = static_cast<float>(row) / lh;
            const float hw = lw * 0.5f * (1.f - t);
            fillRect(ren, cx - hw, ly + static_cast<float>(row), hw * 2.f, 1.f, gc);
        }
    }
    fillRect(ren, cx - 5.f, GroundY - 58.f, 4.f, 7.f, {80, 200, 80, 120});
}

void Obstacle::drawRock(SDL_Renderer* ren) const noexcept
{
    const float cx = x + width() / 2.f;
    const float cy = GroundY - height() / 2.f;
    const float rw = width(), rh = height();

    fillRect(ren, cx - rw/2.f + 4.f, cy - rh/2.f,       rw - 8.f, rh,      {120, 110, 100});
    fillRect(ren, cx - rw/2.f,       cy - rh/2.f + 4.f,  rw,       rh - 8.f,{120, 110, 100});
    fillRect(ren, cx - rw/2.f + 5.f, cy - rh/2.f + 3.f,  rw - 14.f,rh/3.f, {160, 150, 140});
    fillRect(ren, cx - rw/2.f + 3.f, cy + rh/2.f - 6.f,  rw - 7.f, 5.f,    {80,  72,  65});
    fillRect(ren, x + 3.f,           GroundY - 6.f,       5.f,      4.f,    {100,  90,  82});
    fillRect(ren, x + width() - 9.f, GroundY - 5.f,       4.f,      3.f,    {100,  90,  82});
}
